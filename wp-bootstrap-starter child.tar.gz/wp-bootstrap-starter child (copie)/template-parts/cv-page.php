<?php
/**
 * Template Name: CV
 */

get_header(); ?>

	<section id="primary" class="content-area col-sm-12">
		<main id="main" class="site-main" role="main">

		<h2>Amanda Cossu</h2>
		<div>
			<h4><b>Formation</b></h4>
			<p>Développement web, École Centrale de Marseille</p>
			<ul>
				<li>Formation Passerelle Numérique (anciennement SIMPLonMARS)</li>
				<li>En cours </li>
			</ul>
			<br>
			<p>Doctorat en Biochimie et Biologie Moléculaire, Université Fédérale du Rio Grande do Norte (Brésil)</p>
			<ul>
			<li>Mars 2010 - Octobre 2015</li>
			</ul>
			<br>
			<h4><b>Expériences professionnelles</b></h4>
			<p>Enseignant remplaçant, Université de l’État de Paraíba (Brésil) </p>
			<ul>
			<li>Février 2016 - Juin 2016</li>
			</ul>
			<br>
			<p>Stagiaire, Centre de Recherche en Cancérologie de Marseille </p>
			<ul>
			<li>Octobre 2012 - Mars 2014</li>
			</ul>
			<h4><b>Compétences</b></h4>
			<p>HTML5</p>
			<p>CSS3</p>
			<p>Angular5</p>
			<p>Git</p>
			<p>MySQL / SQL</p>
			<p>Javascript</p>
			<p>Wordpress</p>
		</div>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_footer();
