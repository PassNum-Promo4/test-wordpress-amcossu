<?php get_header(); ?>
<?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>
    <article class="projet">
      <?php the_post_thumbnail( 'large' ); ?>
      <h1 class="title">
        <?php the_title(); ?>
      </h1>
      <div class="content">
        <?php the_content(); ?>
      </div>
    </article>
    <!-- CONTENU ACF -->
		<?php
			// Contrôler si ACF est actif
			if ( !function_exists('get_field') ) return;
		?>
	
    	<ul>
			<li><strong>Titre du projet: </strong><?php the_field('titre_du_projet'); ?></li>
			<li><strong>Description: </strong><?php the_field('description'); ?></li>
      <li><strong>Technologies utilisées: </strong><?php the_field('technologies_utilisees'); ?></li>
		</ul>
        <img src="<?php the_field('aperçu_du_projet'); ?>">

<!-- CONTENU ACF -->
  <?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); ?>