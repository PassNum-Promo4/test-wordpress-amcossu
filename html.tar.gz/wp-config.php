<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wordpressuser');

/** MySQL database password */
define('DB_PASSWORD', 'promo4');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('FS_METHOD', 'direct');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ',eE-4kugj,!]dF~U1eVCb,i4CWZsUMO?vv={<t3ea{O|uS&#G20aq,Y3-czHb DF');
define('SECURE_AUTH_KEY',  '^mP?D3]=)qF-](~X^i#2aH^2R}d(!vt4im]nFbB]hFJ#>gWH4F.zb+&ZZxDURJ$v');
define('LOGGED_IN_KEY',    'O!8t%;vL#TsR:Z`AA}aH*n)Z15&a]onX4X(mqh-M^$(O6-S3=rGw>|rw$w=Lw0s>');
define('NONCE_KEY',        'Mq`e&wUhJ.xHJWH~fqh0v/+C6fR(2yE@b+g/K2I K]WE1~+XV4$fT`b0E(NHB{mx');
define('AUTH_SALT',        '0&NW4i/Y_ul7<$5 `;eT-LKF|um1PRC{T,_%s79EU8{Zd4BJ&BPpeF=<]US+BXy>');
define('SECURE_AUTH_SALT', 'k+7qKOT)cDez [Nc9iz2>g|gGlga[#]|~GCPf`l8,k&U|1)N!oXJMm7{pC}9v|-T');
define('LOGGED_IN_SALT',   '&idJ?G/6[*$9%PD,=soH,}mfS25Yfmj{D6/ahDXv*oU|N%e4Hv8VW1M# $~>x%kO');
define('NONCE_SALT',       'Va_%1jnZ+q|rQ-|dfGOIJZkBJeP.JYc-R+enr)@IMV0b5f*u )u-m1Vm;y;(L_jn');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
